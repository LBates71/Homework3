﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;

using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using Windows.Globalization; // Provides access to Globalization settings APIs
using Windows.System.UserProfile; // Provides access to user preference setting APIs
using System.ComponentModel;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace Homework1BaseCode
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {

        public MainPage()
        {
            this.InitializeComponent();
        }


        private async void LangButton_Click(object sender, RoutedEventArgs e)
        {
            string langToPass = GlobalizationPreferences.Languages.First();
            LanguageObject[] availableLanguages = await OpenFlowerProxy.GetLanguages(langToPass);
            List<LocalizedName> holdLang;
            string langText = "";
            string nativeText = " ";
            string localText = "";

            for (int i = 0; i < availableLanguages.Length; i = i + 1)
            {
                langText = langText + availableLanguages[i].LanguageId;
                nativeText = nativeText + availableLanguages[i].NativeName;
                holdLang = availableLanguages[i].LocalizedNames;

                for (int y = 0; y < holdLang.Count; y++)
                {
                    localText = localText + holdLang[y].Value;
                }

                if (i < availableLanguages.Length - 1)
                {
                    langText = langText + ", ";
                    nativeText = nativeText + ", ";
                    localText = localText + ", ";
                }
            }
            //Language_ID.Text = "Language IDs: " + langText;
            //Native_Names.Text = "Native Names: " + nativeText;
            //Localized_Names.Text = "Localized Names: " + localText;

        }

        private async void MarketButton_Click(object sender, RoutedEventArgs e)
        {
            string langToPass = GlobalizationPreferences.Languages.First();
            MarketObject[] availableMarkets = await OpenFlowerProxy.GetMarkets(langToPass);
            string marketText = "";

            for (int i = 0; i < availableMarkets.Length; i = i + 1)
            {
                marketText = marketText + availableMarkets[i].MarketId + '|';
                //MarketTextBlock.Text = marketText;
            }
        }

        private async void FlowerButton_Click(object sender, RoutedEventArgs e)
        {
            string langToPass = GlobalizationPreferences.Languages.First();
            string homeRegion = GlobalizationPreferences.HomeGeographicRegion;
            //string userGeoRegion = new GeographicRegion(homeRegion).ToString();

            FlowerObject[] availableFlowers = await OpenFlowerProxy.GetFlowers(langToPass, homeRegion);
            string flowerText = "";

            for (int i = 0; i < availableFlowers.Length; i = i + 1)
            {
                flowerText = flowerText + availableFlowers[i].GlobalDisplayName + '|';
                //FlowerTextBlock.Text = flowerText;
            }
        }

        private async void GetFlowersByMarketButton_Click(object sender, RoutedEventArgs e) {
            string langToPass = GlobalizationPreferences.Languages.First();
            string homeRegion = GlobalizationPreferences.HomeGeographicRegion;
            string market = GlobalizationPreferences.HomeGeographicRegion.ToLower();
            string marketFlowersInfo = "";
            List<PriceInfo> holdPrices;

            FlowersByMarketObject[] flowersByMarket = await OpenFlowerProxy.GetFlowersByMarket(langToPass, homeRegion, market);

            for (int i = 0; i < flowersByMarket.Length; i = i + 1) {
                marketFlowersInfo = marketFlowersInfo + flowersByMarket[i].GlobalDisplayName + ":\n";
                holdPrices = flowersByMarket[i].PriceInfos;

                for (int y = 0; y < holdPrices.Count; y++)
                {
                    marketFlowersInfo = marketFlowersInfo + holdPrices[y].MarketId + " price = " + holdPrices[y].Currency+holdPrices[y].Price + "\n";
                }
            }
            FlowersByMarketTextBlock.Text = marketFlowersInfo;
        }

        private async void GetOccasionsByMarketButton_Click(object sender, RoutedEventArgs e)
        {
            string langToPass = GlobalizationPreferences.Languages.First();
            string homeRegion = GlobalizationPreferences.HomeGeographicRegion;
            string market = GlobalizationPreferences.HomeGeographicRegion.ToLower();
            string occasionInfo = "";

            OccasionsByMarketObject[] occasionsByMarket = await OpenFlowerProxy.GetOccasionsByMarket(langToPass, homeRegion, market);

            for (int i = 0; i < occasionsByMarket.Length; i = i + 1)
            {
                occasionInfo = occasionInfo + occasionsByMarket[i].GlobalDisplayName + ", ";
            }
            OccasionsByMarketTextBlock.Text = occasionInfo;
        }

        private async void GetFlowersByMarketOccasionButton_Click(object sender, RoutedEventArgs e)
        {
            string langToPass = GlobalizationPreferences.Languages.First();
            string homeRegion = GlobalizationPreferences.HomeGeographicRegion;
            string market = GlobalizationPreferences.HomeGeographicRegion.ToLower();
            string occasion = "60";
            string flowerOccasionMarketInfo = "";

            FlowersByMarketOccasionObject[] flowersByMarkOcc = await OpenFlowerProxy.GetFlowersByMarketOccasion(langToPass, homeRegion, market, occasion);

            for (int i = 0; i < flowersByMarkOcc.Length; i = i + 1)
            {
                flowerOccasionMarketInfo = flowerOccasionMarketInfo + flowersByMarkOcc[i].FlowerId + " - " + flowersByMarkOcc[i].GlobalDisplayName + " Your price: " + flowersByMarkOcc[i].PriceInfoOfCurrentBillingRegion.Currency + flowersByMarkOcc[i].PriceInfoOfCurrentBillingRegion.Price;
            }
            FlowersByMarketOccasionTextBlock.Text = flowerOccasionMarketInfo;

        }
    }
}